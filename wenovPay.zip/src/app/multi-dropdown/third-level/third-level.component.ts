import { Component, AfterViewInit } from '@angular/core';
import { FormBuilder, FormGroup } from '@angular/forms';
import { FormControl, Validators } from '@angular/forms';

@Component({
  selector: 'app-third-level',
  templateUrl: './third-level.component.html'
})
export class ThirdLevelComponent implements AfterViewInit {
  ngAfterViewInit() {}
}
