export class User {
    id!: number;
    name!:string;
    message!: string;
    account_id!: number;
    language!:string;
    token!: string;
    TypeUserId!:number;
    LevelUserId!:number;
    verified_identity!:number;
}