export class UserToken {
  token!: string;
}
